# Personal Telegram Approval Bridge (local starter)

This is a **local** Telegram personal-account client, with optional AI-assisted drafts and an **explicit approval requirement for each outgoing message**. This project **does not connect to ChatGPT itself** and does not magically give an AI access to your Telegram inbox. It is a verifiable first-stage prototype, not a hosted production app. The Telegram login session is kept encrypted locally. Optional AI drafting uses your own OpenAI API key and incurs API charges.

## Privacy and scope

- Uses the **personal Telegram MTProto client API** (teleproto, the maintained GramJS fork), NOT the Bot API.
- `chats` retrieves only local dialogue metadata. `read` displays up to 12 text messages **locally**.
- No chat messages go to OpenAI unless you use `ai-draft`, have recorded chat-specific participant consent, and explicitly confirm that individual disclosure.
- Telegram limits using content obtained from the platform for AI. Its terms say exceptions **may** be granted with explicit, informed, affirmative and ongoing consent from all relevant users, limited to the specific chat and content. An attestation in this app does NOT guarantee Telegram will grant an exception. Check the terms at https://telegram.org/tos/content-licensing and https://core.telegram.org/api/terms, and do not use `ai-draft` unless your use is allowed.
- For safety, prototype only supports one-to-one chats. It does not use secret chats, bulk collection, message search, unattended sending, or group AI ingestion.
- Every outgoing send requires **recipient review and a typed, draft-specific approval**. The local approval itself is not a substitute for ChatGPT host approval if you later build an MCP connector.
- Session and drafts are encrypted locally with AES-256-GCM and a passphrase you enter for each run. Lost passphrase means you must re-authenticate. Do not back up plaintext `.env` or copy `.local` to insecure locations.
- Avoid storing `.env` inside a synced folder or committing it to Git. Keep the API hash and Telegram one-time code **out of ChatGPT and screenshots**.
- Use a dedicated computer you control for the local MVP. Do not run unreviewed third-party clients on your primary account.

## 1. You already finished this step

Create a Telegram API app at https://my.telegram.org under **API development tools**. Your application is already active per screenshot. You should see:
- `api_id` (numeric identifier)
- `api_hash` (secret)

Keep these credentials private; the `api_hash` is not a Telegram login code, and your **session** obtained during client login is even more sensitive.

## 2. Prerequisites

Install Node.js 20 or newer on macOS, Windows, or Linux:
https://nodejs.org/en/download

Unzip this folder somewhere private on the computer. Open Terminal/PowerShell in the **telegram_personal_bridge** folder.

macOS/Linux:

```bash
cp .env.example .env
npm install
```

Windows PowerShell:

```powershell
Copy-Item .env.example .env
npm install
```

Open `.env` in a local editor and enter your numeric `TELEGRAM_API_ID` and secret `TELEGRAM_API_HASH`. Do not surround with quotation marks; do not submit `.env` to ChatGPT. You can leave `OPENAI_API_KEY` empty to test Telegram first.

## 3. First Telegram login

```bash
npm run login
```

You'll be prompted locally for:
1. A **new** strong passphrase to encrypt the locally stored session (not your Telegram password).
2. Confirmation of the new passphrase.
3. Your Telegram phone number in international format, e.g. `+1...`.
4. A Telegram one-time code that arrives in the official Telegram app. Type it **only into the terminal** where you initiated the login.
5. Your Telegram 2-step verification password, if enabled. Some accounts may also require Telegram login email verification. Do not confuse those with the new vault passphrase.

A successful login creates `.local/vault.json` with an encrypted session (not a plaintext session token). The computer must remain secure. Never share `.local/vault.json` together with your vault password.

## 4. Verify that the account connected

```bash
npm run chats
```

This lists direct-chat titles without printing message content to an AI service. Then test your sending/approval workflow **with yourself**, not a contact:

```bash
npm run test
```

It should show the exact message and recipient **Your Saved Messages**. It will not send unless you type `SEND TO MYSELF`. Check Telegram's Saved Messages afterward.

## 5. Read personal messages locally

```bash
npm start -- read
```

Select a one-to-one chat number. The last 12 messages are shown **on your terminal only**. No OpenAI request is made.

## 6. Draft a reply manually and approve it

```bash
npm start -- manual-draft
npm start -- pending
npm start -- send <draft-id>
```

Replace `<draft-id>` with the ID printed when the draft is created. You see the recipient and exact message before sending. Enter `SEND <draft-id>` to approve. If a new message arrived after the draft was created, the send is rejected; create a fresh draft.

If the network fails during sending, the draft is marked `uncertain`, not retried, to avoid duplicates. Check Telegram manually.

## 7. Optional: AI-assisted reply drafting

**Only for chat content whose participants have explicitly consented, and only if permitted under Telegram's terms.** Without this consent, stick to the local reading and manual drafting workflow. This project neither uses scraped bulk content nor trains models on messages. The AI draft feature nevertheless transmits text to a third-party model, so the consent condition matters.

Obtain a separate OpenAI API key at https://platform.openai.com/api-keys and enter it in `.env` as `OPENAI_API_KEY`. This is **not** your ChatGPT subscription; API usage is billed separately.

```bash
npm start -- consent
npm start -- ai-draft
npm start -- pending
npm start -- send <draft-id>
```

1. `consent` records your attestation that all relevant chat participants gave specific, informed, ongoing consent for the AI sharing. That record is encrypted. It is not a legal or Telegram-issued approval.
2. `ai-draft` requires another explicit confirmation before sending **at most 12** recent text messages to OpenAI for a candidate reply. AI message text is treated as untrusted data, not command instructions.
3. The AI suggests a message but **does not send it**.
4. You may save the suggested text to a pending draft and approve it separately.
5. `revoke` disables further AI drafting for a selected chat and deletes its pending drafts.

There is no unattended sync, no scheduler, and no global consent toggle. This prototype does not independently verify recipient consent or guarantee deletion of prior API requests. Review privacy retention arrangements with the provider.

## 8. How we eventually connect this to ChatGPT

This code is not an MCP server; it's a safe, local connectivity MVP. For ChatGPT itself to access your tool, a custom **remote MCP** connector with secure authentication and approval endpoints must be implemented and attached to ChatGPT, subject to the account/workspace eligibility requirements and mobile/web availability. See https://help.openai.com/en/articles/12584461-connecting-custom-mcp-servers-in-chatgpt . Do not expose the CLI via an unprotected public URL.

A separate independent web app with a React Native frontend and a protected private backend is another route if your plan doesn't support write-enabled custom ChatGPT connectors. Store Telegram sessions **server-side only**, never in Expo/React Native code or Supabase's public tables. Use auth, row-level access controls and an idempotent approval queue.

## 9. Maintained client library

This starter uses [teleproto](https://docs.teleproto.dev/), the maintained fork of the now-archived GramJS project. It follows the supported MTProto personal-account client flow. No bot token is needed.

## 10. Security and risk notes

- Read https://core.telegram.org/api/terms and https://telegram.org/tos/content-licensing. Telegram says that unofficial API clients are monitored and can be restricted for abuse. Avoid spam, automation at scale and unsolicited bulk messages.
- Do not open confidential chats until you've reviewed how you will use and store the data.
- **Do not paste login codes, API hash, session tokens or OpenAI API keys into ChatGPT.**
- Telegram secret chats are not covered by this standard cloud-chat prototype.
- Anyone controlling an authorized local process with the Telegram session can act on your Telegram account. Treat this machine as sensitive, use full-disk encryption, and protect it from malware.
- On macOS/Linux `.local/vault.json` is created mode `0600`; on Windows ensure filesystem user permissions are correctly restricted.
- `npm install` downloads third-party dependencies. Audit the code and its dependencies before using a real personal account.

## Next milestone

After the local test message reaches Saved Messages, implement a **hardened remote MCP bridge** or an authenticated Expo dashboard. That second phase requires additional hosting, authentication, storage, audit logging, rate limits, Telegram terms review and possibly ChatGPT plan eligibility. Do not confuse successful Telegram app registration with a completed ChatGPT connector.
